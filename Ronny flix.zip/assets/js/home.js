
document.addEventListener('DOMContentLoaded', function () {
    const heroSection = document.getElementById('hero');
    const loadingSpinner = document.querySelectorAll('.loading-spinner');
    const contentgrid = document.querySelectorAll('.content-grid');


    let activeHoverInfo = null; // Variable to track the active hover info



    // JavaScript for managing the welcome screen and loader
    const welcomeScreen = document.getElementById('welcome-screen');

    // Check if the user has already visited
    const hasVisited = sessionStorage.getItem('ronnyflixVisited');

    if (!hasVisited) {
        // Show welcome screen
        welcomeScreen.classList.remove('hidden');

        // Fade out the welcome screen after 3 seconds
        setTimeout(() => {
            welcomeScreen.classList.add('fade-out'); // Add fade-out class
            setTimeout(() => {
                welcomeScreen.classList.add('hidden'); // Fully hide welcome screen
                sessionStorage.setItem('ronnyflixVisited', 'true'); // Mark as visited
            }, 1000); // Matches the CSS transition duration
        }, 3000); // 3-second delay
    } else {
        // Skip welcome screen
        welcomeScreen.remove();
    }



   // Move fetchAndDisplayMovies definition here
    function fetchAndDisplayMovies(url, containerId) {
        showLoadingSpinner(); // Show loading spinner
        fetch(url)
            .then(response => response.json())
            .then(data => {
                const movies = data.results;
                const container = document.getElementById(containerId);
                container.innerHTML = ''; // Clear previous content
                movies.forEach(movie => {
                    const movieItem = document.createElement('div');
                    movieItem.classList.add('content-item');
                    movieItem.innerHTML = `
                            <img src="https://image.tmdb.org/t/p/w500${movie.poster_path}" alt="${movie.title}">
                            <div class="content-info">
                                <h3>${movie.title}</h3>
                                <p><b>Release :</b> ${movie.release_date}</p>
                            </div>
                            <div class="hover-info">
                                <h3>${movie.title}</h3>
                                <p><b>Release :</b> ${movie.release_date}</p>
                                <button class="details-button" data-media-id="${movie.id}" data-type="movie"">Watch <i class="fa-solid fa-arrow-up-right-from-square"></i></button>
                            </div>
                                                                                        <p class="content-type">Movies</p>

                        `;

                    // Event listener for movie item click
                    movieItem.addEventListener('click', () => {
                        if (activeHoverInfo) {
                            activeHoverInfo.style.transform = "translatex(100%)";
                        }
                        const hoverInfo = movieItem.querySelector('.hover-info');
                        hoverInfo.style.transform = "translatex(-100%)";
                        activeHoverInfo = hoverInfo;
                    });

                    // Event listener for details button
                    movieItem.querySelector('.details-button').addEventListener('click', (event) => {
                        window.location.href = `details.html?movieId=${movieId}`;
                    });

                    container.appendChild(movieItem);
                });

                hideLoadingSpinner(); // Hide loading spinner

            })
            .catch(() => {
                hideLoadingSpinner(); // Hide loading spinner
                // window.location.href = `R/error.html`;
            });
    }





    // Fetch and display TV shows
    function fetchAndDisplayTVShows(url, containerId) {
        showLoadingSpinner(); // Show loading spinner
        fetch(url)
            .then(response => response.json())
            .then(data => {
                const shows = data.results;
                const container = document.getElementById(containerId);
                container.innerHTML = ``; // Clear previous content
                shows.forEach(show => {
                    const showItem = createMediaItem(show, 'tv');
                    container.appendChild(showItem);
                });
                hideLoadingSpinner(); // Hide loading spinner
            })
            .catch(() => {
                hideLoadingSpinner(); // Hide loading spinner
                // window.location.href = `R/maintenance.html`; 
            });
    }






    // Function to create media item (movies and TV shows)
    function createMediaItem(media, type) {
        const mediaItem = document.createElement('div');
        mediaItem.classList.add('content-item');
        mediaItem.innerHTML = `
            <img src="https://image.tmdb.org/t/p/w500${media.poster_path}" alt="${media.title || media.name}">
            <div class="content-info">
                <h3>${media.title || media.name}</h3>
                <p><b>Release :</b> ${media.release_date || media.first_air_date}</p>
            </div>
            <div class="hover-info">
                <h3>${media.title || media.name}</h3>
                <p><b>Release :</b> ${media.release_date || media.first_air_date}</p>
                <button class="details-button series-details-button" data-media-id="${media.id}" data-type="${type}">Watch <i class="fa-solid fa-arrow-up-right-from-square"></i></button>
            </div>
                                                            <p class="content-type">Series</p>

           `;

        // Add event listener to the media item
        mediaItem.addEventListener('click', () => {
            if (activeHoverInfo) {
                activeHoverInfo.style.transform = "translatex(100%)";
            }
            const hoverInfo = mediaItem.querySelector('.hover-info');
            hoverInfo.style.transform = "translatex(-100%)";
            activeHoverInfo = hoverInfo;
        });

        return mediaItem;
    }

    // Delegate click event for details buttons
    document.addEventListener('click', (event) => {
        if (event.target.classList.contains('details-button')) {
            const mediaId = event.target.getAttribute('data-media-id');
            const type = event.target.getAttribute('data-type');

            if (type === "movie") {
                window.location.href = `details.html?movieId=${mediaId}`;
            } else {
                window.location.href = `tv-show-details.html?tvId=${mediaId}`;
            }
        }
    });






    function fetchRandomHeroImage() {
        const urls = [
            `https://api.themoviedb.org/3/movie/popular?api_key=${apiKey}`,
            `https://api.themoviedb.org/3/movie/now_playing?api_key=${apiKey}`,
            `https://api.themoviedb.org/3/movie/top_rated?api_key=${apiKey}`
        ];

        const randomUrl = urls[Math.floor(Math.random() * urls.length)];

        fetch(randomUrl)
            .then(response => response.json())
            .then(data => {
                const movies = data.results;
                const randomMovie = movies[Math.floor(Math.random() * movies.length)];
                const heroImageUrl = `https://image.tmdb.org/t/p/w1280${randomMovie.backdrop_path}`;
                updateHeroImage(heroImageUrl);
            })
            .catch(() => {
                const heroImageUrl = `(../The\ Garfield\ Movie.jpg`;
                updateHeroImage(heroImageUrl);
            });
    }

    function updateHeroImage(imageUrl) {
        const currentImage = document.querySelector('.hero-image.active');
        const newImage = document.createElement('div');
        newImage.className = 'hero-image';
        newImage.style.backgroundImage = `url(${imageUrl})`;
        heroSection.appendChild(newImage);

        // Triggering the fade-in effect
        setTimeout(() => {
            newImage.classList.add('active');
            currentImage.classList.remove('active');

            // Remove the old image after the transition
            setTimeout(() => {
                heroSection.removeChild(currentImage);
            }, 1000); // Match the transition duration in CSS
        }, 50);
    }

    function showLoadingSpinner() {
        loadingSpinner.forEach(e => {
            e.style.display = "block"
        })
    }

    function hideLoadingSpinner() {
        loadingSpinner.forEach(e => {
            e.style.display = "none"
        })

        }


    // ------------------------------------
    // ------------crousel control-------------
    // ------------------------------------

    function rightControl(crosuel_container) {
        const container = document.getElementById(crosuel_container);
        container.scrollBy({ left: 450, behavior: 'smooth' });
    }

    function leftControl(crosuel_container) {
        const container = document.getElementById(crosuel_container);
        container.scrollBy({ left: -450, behavior: 'smooth' });
    }

    document.getElementById('new-releases-grid-left-control')?.addEventListener('click', function () {
        leftControl("new-releases-grid")
    });

    document.getElementById('new-releases-grid-right-control')?.addEventListener('click', function () {
        rightControl("new-releases-grid")
    });

    document.getElementById('featured-tv-grid-left-control')?.addEventListener('click', function () {
        leftControl("featured-tv-grid")
    });

    document.getElementById('featured-tv-grid-right-control')?.addEventListener('click', function () {
        rightControl("featured-tv-grid")
    });

    document.getElementById('featured-grid-left-control')?.addEventListener('click', function () {
        leftControl("featured-grid")
    });

    document.getElementById('featured-grid-right-control')?.addEventListener('click', function () {
        rightControl("featured-grid")
    });

    document.getElementById('trending-grid-left-control')?.addEventListener('click', function () {
        leftControl("trending-grid")
    });

    document.getElementById('trending-grid-right-control')?.addEventListener('click', function () {
        rightControl("trending-grid")
    });

    document.getElementById('trending-tv-grid-left-control')?.addEventListener('click', function () {
        leftControl("trending-tv-grid")
    });

    document.getElementById('trending-tv-grid-right-control')?.addEventListener('click', function () {
        rightControl("trending-tv-grid")
    });


    // Select the button
    const scrollToTopBtn = document.getElementById('scrollToTopBtn');

    // Show or hide the button based on scroll position
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollToTopBtn.classList.add('show');
        } else {
            scrollToTopBtn.classList.remove('show');
        }
    });

    // Scroll to the top when the button is clicked
    scrollToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });




    fetchAndDisplayMovies(`https://api.themoviedb.org/3/movie/popular?api_key=${apiKey}`, 'featured-grid');
    fetchAndDisplayMovies(`https://api.themoviedb.org/3/movie/top_rated?api_key=${apiKey}`, 'trending-grid');
    fetchAndDisplayMovies(`https://api.themoviedb.org/3/movie/now_playing?api_key=${apiKey}`, 'new-releases-grid');
    fetchAndDisplayTVShows(`https://api.themoviedb.org/3/tv/popular?api_key=${apiKey}`, 'featured-tv-grid');
    fetchAndDisplayTVShows(`https://api.themoviedb.org/3/tv/top_rated?api_key=${apiKey}`, 'trending-tv-grid');

    fetchRandomHeroImage();
    setInterval(fetchRandomHeroImage, 10000); // Change hero image every 10 seconds




});