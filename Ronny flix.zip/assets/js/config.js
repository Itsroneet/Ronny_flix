// TMDB Api key
const apiKey = '5a41a4ff0e4bfcc5608165fe4ae559ed';
// Firebase configuration and initialization
const firebaseConfig = {
    apiKey: "AIzaSyB3Kp1AF1CgMRbMaJMyHy5Wk9nh5PVWW_s",
    authDomain: "ronnyflix-np.firebaseapp.com",
    projectId: "ronnyflix-np",
    storageBucket: "ronnyflix-np.appspot.com",
    messagingSenderId: "1061623989741",
    appId: "1:1061623989741:web:9cc3afc1873c7d972313e4",
    measurementId: "G-KPWBSTM31K"
};

